package com.lakh.leadautomaton

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.content.Context
import android.view.View
import android.widget.*
import java.util.Locale

data class Lead(var name:String, var business:String, var location:String, var contact:String, var score:Int, var status:String, var notes:String="")

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private lateinit var log: TextView
    private val leads = mutableListOf<Lead>()
    private var running = false
    private val prefs by lazy { getSharedPreferences("lakh", Context.MODE_PRIVATE) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        load()
        dashboard()
    }

    private fun shell(title:String): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24,24,24,20)
            setBackgroundColor(Color.rgb(247,247,249))
        }
        val head = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        val t = TextView(this).apply { text=title; textSize=25f; setTextColor(Color.BLACK); setTypeface(null,1) }
        head.addView(t, LinearLayout.LayoutParams(0,70,1f))
        val home=Button(this).apply { text="⌂"; setOnClickListener{dashboard()} }
        head.addView(home, LinearLayout.LayoutParams(70,70))
        root.addView(head)
        body=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        val scroll=ScrollView(this).apply { addView(body) }
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        return root
    }

    private fun btn(text:String, f:()->Unit)=Button(this).apply{ this.text=text; setOnClickListener{f()} }
    private fun label(s:String)=TextView(this).apply{ text=s; textSize=16f; setTextColor(Color.DKGRAY); setPadding(4,10,4,6) }
    private fun input(h:String)=EditText(this).apply{ hint=h; setSingleLine(true); setPadding(16,8,16,8) }

    private fun dashboard(){
        shell("LAKH LEAD AUTOMATON")
        body.addView(label("AI Company • Lead Manager + Specialized Agents"))
        val status=label(if(running) "● AUTOMATION RUNNING" else "● AUTOMATION PAUSED")
        status.setTextColor(if(running) Color.rgb(20,130,70) else Color.DKGRAY)
        body.addView(status)
        body.addView(btn(if(running)"⏸ PAUSE AUTOMATION" else "▶ START AUTONOMOUS WORK"){
            running=!running; logEvent(if(running)"Automation started" else "Automation paused"); dashboard()
        })
        body.addView(btn("🔎 LEAD HUNTER"){leadHunter()})
        body.addView(btn("🧠 LEAD QUALIFICATION"){qualification()})
        body.addView(btn("✉ AI OUTREACH"){outreach()})
        body.addView(btn("📥 AI INBOX"){inbox()})
        body.addView(btn("🔥 HOT LEADS"){hotLeads()})
        body.addView(btn("📅 FOLLOW-UPS"){followups()})
        body.addView(btn("📊 ANALYTICS"){analytics()})
        body.addView(btn("📋 AGENT ACTIVITY LOG"){activity()})
        body.addView(btn("⚙ SETTINGS"){settings()})
    }

    private fun leadHunter(){
        shell("Lead Hunter")
        val business=input("Business type (e.g. café)"); val loc=input("Location (e.g. California)")
        val target=input("Target client / niche"); val contact=input("Website, email or WhatsApp")
        body.addView(business); body.addView(loc); body.addView(target); body.addView(contact)
        body.addView(btn("＋ ADD LEAD"){
            val n=if(target.text.isNullOrBlank()) "New Lead" else target.text.toString()
            val l=Lead(n,business.text.toString(),loc.text.toString(),contact.text.toString(),70,"New")
            leads.add(l); save(); logEvent("Lead added: $n"); toast("Lead saved"); leadHunter()
        })
        body.addView(label("Saved leads: ${leads.size}"))
        leads.forEachIndexed { i,l -> body.addView(leadCard(l,i)) }
    }

    private fun leadCard(l:Lead,i:Int): LinearLayout {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL; setPadding(12,10,12,10)}
        box.addView(label("${l.name} • Score ${l.score} • ${l.status}"))
        box.addView(TextView(this).apply{text="${l.business} | ${l.location}\nContact: ${l.contact}"; textSize=14f})
        val row=LinearLayout(this)
        row.addView(btn("Qualify"){qualifyOne(i)},LinearLayout.LayoutParams(0,-2,1f))
        row.addView(btn("Delete"){leads.removeAt(i);save();leadHunter()},LinearLayout.LayoutParams(0,-2,1f))
        box.addView(row)
        return box
    }

    private fun qualifyOne(i:Int){
        val l=leads[i]
        l.score=(l.score+10).coerceAtMost(100); l.status=if(l.score>=80)"Qualified" else "Needs Review"
        save(); logEvent("Qualified ${l.name}: ${l.score}"); toast("Score updated to ${l.score}"); leadHunter()
    }

    private fun qualification(){
        shell("Lead Qualification")
        if(leads.isEmpty()){body.addView(label("No leads yet. Add leads from Lead Hunter."));return}
        leads.sortedByDescending{it.score}.forEachIndexed{_,l->
            body.addView(label("${l.name} — ${l.score}/100 — ${l.status}"))
        }
        body.addView(btn("AUTO-QUALIFY ALL"){
            leads.forEach{it.score=(it.score+15).coerceAtMost(100);it.status=if(it.score>=80)"Qualified" else "Review"}
            save();logEvent("Auto-qualified ${leads.size} leads");qualification()
        })
    }

    private fun outreach(){
        shell("AI Outreach")
        if(leads.isEmpty()){body.addView(label("Add a lead first."));return}
        leads.forEachIndexed{i,l->
            val msg="Hi ${l.name}, I came across ${l.business} in ${l.location}. I noticed an opportunity to improve customer acquisition and would love to share a quick idea. Open to a short chat?"
            body.addView(label("${l.name}"))
            body.addView(TextView(this).apply{text=msg;textSize=14f;setPadding(8,4,8,8)})
            body.addView(btn("Mark Contacted"){l.status="Contacted";save();logEvent("Outreach drafted/marked contacted: ${l.name}");outreach()})
        }
    }

    private fun inbox(){
        shell("AI Inbox")
        val reply=input("Paste a client reply to classify")
        body.addView(reply)
        body.addView(btn("ANALYZE REPLY"){
            val s=reply.text.toString().lowercase(Locale.getDefault())
            val result=when{
                listOf("interested","yes","sure","let's talk","lets talk","call me","price","details").any{s.contains(it)}->"INTERESTED 🔥"
                listOf("maybe","later","next week","think","consider").any{s.contains(it)}->"MAYBE"
                listOf("no thanks","not interested","stop","remove").any{s.contains(it)}->"NOT INTERESTED"
                else->"FOLLOW-UP"
            }
            body.addView(label("RESULT: $result"))
            if(result.startsWith("INTERESTED")){toast("HOT LEAD detected");logEvent("HOT LEAD from reply")}
        })
    }

    private fun hotLeads(){
        shell("🔥 Hot Leads")
        val hot=leads.filter{it.score>=80 || it.status=="Interested"}
        if(hot.isEmpty())body.addView(label("No hot leads yet."))
        hot.forEach{body.addView(label("🔥 ${it.name} — ${it.score}/100 — ${it.contact}"))}
    }

    private fun followups(){
        shell("📅 Follow-ups")
        leads.filter{it.status=="Contacted"||it.status=="Maybe"}.forEach{i->
            body.addView(btn("Follow up: ${i.name}"){i.status="Follow-up Sent";save();logEvent("Follow-up sent/drafted: ${i.name}");followups()})
        }
        if(leads.none{it.status=="Contacted"||it.status=="Maybe"})body.addView(label("No follow-ups pending."))
    }

    private fun analytics(){
        shell("📊 Analytics")
        val qualified=leads.count{it.score>=80}; val contacted=leads.count{it.status.contains("Contacted")||it.status.contains("Follow")}
        val hot=leads.count{it.score>=80||it.status=="Interested"}
        body.addView(label("Total leads: ${leads.size}"))
        body.addView(label("Qualified: $qualified"))
        body.addView(label("Contacted: $contacted"))
        body.addView(label("Hot leads: $hot"))
        body.addView(label("Conversion-ready pipeline: ${if(leads.isEmpty())0 else (hot*100/leads.size)}%"))
    }

    private fun activity(){
        shell("📋 Agent Activity")
        log=TextView(this).apply{text=prefs.getString("log","System ready.") ?: "System ready.";textSize=15f;setTextColor(Color.DKGRAY)}
        body.addView(log)
    }

    private fun settings(){
        shell("⚙ Settings")
        body.addView(label("Automation is local in this version. API connections can be added later."))
        body.addView(btn("CLEAR ALL LOCAL LEADS"){leads.clear();save();logEvent("All local leads cleared");settings()})
        body.addView(btn("RESET ACTIVITY LOG"){prefs.edit().remove("log").apply();settings()})
    }

    private fun logEvent(s:String){
        val old=prefs.getString("log","") ?: ""
        prefs.edit().putString("log","✓ $s\n$old".take(8000)).apply()
    }
    private fun save(){
        prefs.edit().putString("leads",leads.joinToString("\u001e"){
            listOf(it.name,it.business,it.location,it.contact,it.score,it.status,it.notes).joinToString("\u001f")
        }).apply()
    }
    private fun load(){
        val raw=prefs.getString("leads","") ?: return
        if(raw.isBlank())return
        raw.split("\u001e").forEach{p->
            val x=p.split("\u001f"); if(x.size>=7) leads.add(Lead(x[0],x[1],x[2],x[3],x[4].toIntOrNull()?:0,x[5],x[6]))
        }
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}

package com.example.lakhleadautomaton

import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : android.app.Activity() {
    private val bg = Color.rgb(11,11,16)
    private val card = Color.rgb(22,22,30)
    private val text = Color.WHITE
    private val muted = Color.rgb(170,170,185)
    private val accent = Color.rgb(124,92,255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showDashboard()
    }

    private fun label(s:String, size:Float=16f): TextView {
        return TextView(this).apply {
            text=s; textSize=size; setTextColor(text); setPadding(18,14,18,14)
        }
    }
    private fun button(s:String, action:()->Unit): Button {
        return Button(this).apply {
            text=s; setTextColor(Color.WHITE); setOnClickListener { action() }
        }
    }
    private fun box(): LinearLayout = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL
        setPadding(16,16,16,16)
        background=GradientDrawable().apply { setColor(card); cornerRadius=28f }
    }

    private fun showDashboard() {
        val root=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setBackgroundColor(bg)
        }
        root.addView(label("Lakh Lead Automaton",26f))
        root.addView(label("AI client-hunting control center",14f).apply{setTextColor(muted)})
        val scroll=ScrollView(this)
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(12,8,12,24)}
        val stats=box()
        stats.addView(label("LIVE DASHBOARD",12f).apply{setTextColor(muted)})
        stats.addView(label("0  Leads     0  Interested     0  Deals",20f))
        stats.addView(label("Agent status: READY",14f).apply{setTextColor(muted)})
        list.addView(stats)
        val menu=box()
        menu.addView(label("AUTOMATION",12f).apply{setTextColor(muted)})
        menu.addView(button("🔎 Lead Hunter"){ showLeadHunter() })
        menu.addView(button("🤖 AI Outreach"){ showMessage("AI Outreach","Ready for approved, non-spam outreach. Connect an approved API later.") })
        menu.addView(button("📥 AI Inbox"){ showMessage("AI Inbox","Reply analysis module is ready for the next integration step.") })
        menu.addView(button("🚨 Deal Alerts"){ showMessage("Deal Alerts","Interested prospects will appear here.") })
        menu.addView(button("📜 Agent Log"){ showMessage("Agent Log","Actions and decisions will be logged here.") })
        menu.addView(button("⚙ Settings"){ showMessage("Settings","API keys and integrations will be added through secure app settings.") })
        list.addView(menu)
        scroll.addView(list); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
    }

    private fun showLeadHunter() {
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bg);setPadding(18,18,18,18)}
        root.addView(label("🔎 Lead Hunter",26f))
        root.addView(label("Find and qualify real prospects without spam.",14f).apply{setTextColor(muted)})
        val country=EditText(this).apply{hint="Country (e.g. Germany)";setTextColor(text);setHintTextColor(muted)}
        val city=EditText(this).apply{hint="City";setTextColor(text);setHintTextColor(muted)}
        val need=EditText(this).apply{hint="Problem / service (e.g. lead follow-up)";setTextColor(text);setHintTextColor(muted)}
        root.addView(country);root.addView(city);root.addView(need)
        root.addView(button("Find prospects"){ Toast.makeText(this,"Lead search connector will run here.",Toast.LENGTH_LONG).show() })
        root.addView(button("← Dashboard"){showDashboard()})
        setContentView(root)
    }

    private fun showMessage(title:String,msg:String){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bg);setPadding(18,18,18,18)}
        root.addView(label(title,26f));root.addView(label(msg,16f).apply{setTextColor(muted)})
        root.addView(button("← Dashboard"){showDashboard()});setContentView(root)
    }
}

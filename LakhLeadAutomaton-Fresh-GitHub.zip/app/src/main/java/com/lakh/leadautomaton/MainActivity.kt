package com.lakh.leadautomaton

import android.app.Activity
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  setContent { App() }
 }
}

@Composable
fun App() {
 var page by remember { mutableStateOf("Dashboard") }
 var running by remember { mutableStateOf(false) }

 MaterialTheme(colorScheme = darkColorScheme()) {
  Scaffold(bottomBar = {
   NavigationBar {
    listOf("Dashboard","Leads","Inbox","Settings").forEach {
     NavigationBarItem(selected=page==it,onClick={page=it},icon={},label={Text(it)})
    }
   }
  }) { pad ->
   Column(Modifier.fillMaxSize().padding(pad).padding(20.dp)) {
    Text("LAKH LEAD AUTOMATON", style=MaterialTheme.typography.headlineSmall)
    Spacer(Modifier.height(16.dp))
    when(page) {
     "Dashboard" -> Dashboard(running) { running=!running }
     "Leads" -> Leads()
     "Inbox" -> Inbox()
     else -> Settings()
    }
   }
  }
 }
}

@Composable
fun Dashboard(running:Boolean,toggle:()->Unit) {
 Text("AI Client Hunter",style=MaterialTheme.typography.titleLarge)
 Spacer(Modifier.height(16.dp))
 Card(Modifier.fillMaxWidth()) {
  Column(Modifier.padding(18.dp)) {
   Text("Lead Overview")
   Text("Leads Found: 128")
   Text("Qualified: 42")
   Text("Interested: 11")
   Text("HOT Leads: 5")
  }
 }
 Spacer(Modifier.height(16.dp))
 Button(onClick=toggle,Modifier.fillMaxWidth()) {
  Text(if(running) "Pause Automation" else "Start Automation")
 }
 Spacer(Modifier.height(8.dp))
 OutlinedButton(onClick={},Modifier.fillMaxWidth()){Text("AI Outreach")}
 OutlinedButton(onClick={},Modifier.fillMaxWidth()){Text("Agent Activity Log")}
 OutlinedButton(onClick={},Modifier.fillMaxWidth()){Text("Follow-ups")}
}

@Composable
fun Leads() {
 Text("Lead Hunter",style=MaterialTheme.typography.titleLarge)
 Spacer(Modifier.height(10.dp))
 OutlinedTextField(value="",onValueChange={},label={Text("Business type / location / target")},Modifier.fillMaxWidth())
 Spacer(Modifier.height(10.dp))
 LazyColumn {
  item { LeadCard("Demo Café","California, USA",92,"HOT") }
  item { LeadCard("Growth Studio","Miami, USA",84,"Qualified") }
  item { LeadCard("Local Restaurant","Texas, USA",71,"New") }
 }
}

@Composable
fun LeadCard(name:String,location:String,score:Int,status:String) {
 Card(Modifier.fillMaxWidth().padding(vertical=5.dp)) {
  Column(Modifier.padding(15.dp)) {
   Text(name,style=MaterialTheme.typography.titleMedium)
   Text(location)
   Text("Score $score • $status")
  }
 }
}

@Composable
fun Inbox() {
 Text("AI Inbox",style=MaterialTheme.typography.titleLarge)
 Spacer(Modifier.height(10.dp))
 listOf("Interested","Maybe","Not Interested","Follow-up").forEach {
  OutlinedButton(onClick={},Modifier.fillMaxWidth()){Text(it)}
 }
}

@Composable
fun Settings() {
 Text("Settings",style=MaterialTheme.typography.titleLarge)
 Spacer(Modifier.height(12.dp))
 Text("Legitimate API integrations only")
 Text("No spam, fake accounts, CAPTCHA bypass or rate-limit bypass.")
 Text("User approval required for outreach.")
}

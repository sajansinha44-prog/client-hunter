package com.example.lakhleadautomaton
import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.widget.*
class MainActivity:Activity(){
 private lateinit var box:LinearLayout
 override fun onCreate(b:Bundle?){super.onCreate(b); dash()}
 fun base(t:String):LinearLayout{val r=LinearLayout(this);r.orientation=LinearLayout.VERTICAL;r.setPadding(28,28,28,28);r.setBackgroundColor(Color.rgb(16,16,20));val h=TextView(this);h.text=t;h.textSize=26f;h.setTextColor(Color.WHITE);r.addView(h);return r}
 fun btn(t:String,f:()->Unit)=Button(this).apply{text=t;setOnClickListener{f()}}
 fun dash(){val r=base("Lakh Lead Automaton");val s=TextView(this);s.text="AI Client Hunter • Android";s.textSize=16f;s.setTextColor(Color.LTGRAY);r.addView(s)
  r.addView(btn("Lead Hunter"){page("Lead Hunter","Find and qualify potential clients.")})
  r.addView(btn("AI Outreach"){page("AI Outreach","Create personalized outreach drafts.")})
  r.addView(btn("AI Inbox"){page("AI Inbox","Analyze replies and detect interested clients.")})
  r.addView(btn("Deal Alerts"){page("Deal Alerts","Show high-intent client alerts.")})
  r.addView(btn("Agent Log"){page("Agent Log","Think → Act → Observe activity.")})
  r.addView(btn("Settings"){page("Settings","Automation controls and integrations.")});setContentView(r)}
 fun page(t:String,d:String){val r=base(t);val x=TextView(this);x.text=d;x.textSize=18f;x.setTextColor(Color.WHITE);r.addView(x);r.addView(btn("← Dashboard"){dash()});setContentView(r)}
}